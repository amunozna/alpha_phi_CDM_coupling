D_M(z_*) in Gpc
\omega_m
D_V(z=0.122)  6dFGS  
D_A(z=0.835)  DESY3
D_V(z=0.44)  WiggleZ
D_V(z=0.60)  WiggleZ
D_V(z=0.73)  WiggleZ
H(z=0.32)    LOWZ
D_A(z=0.32)  LOWZ
H(z=0.57)    CMASS
D_A(z=0.57)  CMASS
D_A(z=1.48)  QSO eBOSS
H(z=1.48)    QSO eBOSS
D_A(z=2.334) Lya-F eBOSS
H(z=2.334)   Lya-F eBOSS

 